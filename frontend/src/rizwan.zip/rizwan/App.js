import { react } from "react";
import Warehouse_create from "./Warehouse_create";


function App(){
    return(
        <div>
            <h1>App</h1>
            <Warehouse_create  />
        </div>
    );
}

export default App;